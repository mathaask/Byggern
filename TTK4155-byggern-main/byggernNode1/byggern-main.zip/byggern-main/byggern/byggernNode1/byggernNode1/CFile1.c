/*
 * CFile1.c
 *
 * Created: 03.10.2023 16:52:52
 *  Author: trygvemt
 */ 
