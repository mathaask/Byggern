/*
 * can_driver.h
 *
 * Created: 03.10.2023 16:53:28
 *  Author: trygvemt
 */ 


#ifndef CAN_DRIVER_H_
#define CAN_DRIVER_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include "mcp2515.h"
#include "spi.h"

typedef struct{
	uint16_t id;
	uint8_t length;
	uint8_t data[8];
	} CAN_message_t;

void can_init(void);

void can_sendMessage(CAN_message_t *msg);

void can_recieveMessage(CAN_message_t *msg);



#endif /* CAN_DRIVER_H_ */