/*
 * mcp2515.c
 *
 * Created: 03.10.2023 10:09:59
 *  Author: trygvemt
 */ 
#include <avr/io.h>
#include "spi.h"
#include "mcp2515.h"

uint8_t mcp2515_read ( uint8_t address )
{
	uint8_t result ;
	PORTB &= ~(1 << DDB4 ); // Select CAN - controller	
	
	SPI_MasterTransmit(MCP_READ);
	SPI_MasterTransmit (address); // Send address
	result = SPI_MasterTransmit(0x00);	
	
	PORTB |= (1 << DDB4 ); // Deselect CAN - controller
	return result ;
	
	//return (SPI_transmit(MCP_READ, address, 0,0));
}void mcp2515_write(uint8_t address, uint8_t data){	PORTB &= ~(1 << DDB4 );	SPI_MasterTransmit(2);	SPI_MasterTransmit(address);	SPI_MasterTransmit(data);	PORTB |= (1 << DDB4 );}uint8_t mcp2515_init(void)
{
	uint8_t value ;
	SPI_MasterInit () ; // Initialize SPI
	mcp2515_reset () ; // Send reset - command
	//CANCTRL 
	// Self - test
	value = mcp2515_read(MCP_CANSTAT);
	printf("value: %d \n\r", value);
	if ((value & MODE_MASK ) != MODE_CONFIG) {
		printf (" MCP2515 is NOT in configuration mode after reset !\n");
		return 1;
	} else {
		printf (" MCP2515 is in configuration mode after reset !\n");
	}
	// More initialization
	printf("value: %d \n\r", value);
	
	return 0;
}

void mcp2515_reset(void){
	PORTB &= ~(1 << DDB4 );
	SPI_MasterTransmit(MCP_RESET); 
	PORTB |= (1 << DDB4 );
}


void mcp2515_request_to_send(uint8_t buffers){
	PORTB &= ~(1 << DDB4 );
	SPI_MasterTransmit(0x80|buffers);
	PORTB |= (1 << DDB4 );
}

uint8_t mcp2515_read_status(void){
	uint8_t dataOut;
	PORTB &= ~(1 << DDB4 );
	SPI_MasterTransmit(MCP_READ_STATUS);
	dataOut = SPI_MasterTransmit(0x00);
	PORTB |= (1 << DDB4 );
	return dataOut;
}

void mcp2515_bit_modify(uint8_t address, uint8_t mask, uint8_t data){
	PORTB &= ~(1 << DDB4 );
	
	SPI_MasterTransmit(5);
	SPI_MasterTransmit(address);
	SPI_MasterTransmit(mask);
	SPI_MasterTransmit(data);
	
	PORTB |= (1 << DDB4 );
}

